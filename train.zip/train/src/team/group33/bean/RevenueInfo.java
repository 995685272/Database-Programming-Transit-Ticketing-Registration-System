package team.group33.bean;

public class RevenueInfo {
    private String total;
    private String orderCreateDate;
    private String ReservationNum;

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getOrderCreateDate() {
        return orderCreateDate;
    }

    public void setOrderCreateDate(String orderCreateDate) {
        this.orderCreateDate = orderCreateDate;
    }

    public String getReservationNum() {
        return ReservationNum;
    }

    public void setReservationNum(String reservationNum) {
        ReservationNum = reservationNum;
    }


}
